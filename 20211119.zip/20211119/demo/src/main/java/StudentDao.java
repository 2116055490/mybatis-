/**
 * @author l.
 * @date 2021/11/19.
 * @time 19:03.
 */
public interface StudentDao {
    public void insertStudent(Student student);
}
