import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author l.
 * @date 2021/11/19.
 * @time 21:02.
 */
public class StudentDaoImpl implements StudentDao{

    private SqlSession sqlSession;
    @Override
    public void insertStudent(Student student) {
        try{
            //读取配置文件
            InputStream resourceAsStream = Resources.getResourceAsStream("mybatis.xml");
            //创建SqlSessionFactory对象
            SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
            //创建SqlSession对象
            SqlSession sqlSession = build.openSession();
            //新增数据操作
            sqlSession.insert("insertStudent",student);
            //提交SqlSession
            sqlSession.commit();
        }catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (sqlSession != null){
                sqlSession.close();
            }
        }


    }



}
