import org.testng.annotations.Test;

/**
 * @author l.
 * @date 2021/11/19.
 * @time 21:19.
 */
public class Tests {


    @Test
    public void insertStudent(){
        StudentDaoImpl studentDao = new StudentDaoImpl();
        Student student = new Student();
        student.setAge(1);
        student.setName("刘德华");
        student.setScore(98.50);
        studentDao.insertStudent(student);
    }
}
